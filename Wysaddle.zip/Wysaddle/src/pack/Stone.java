package pack;

public class Stone {

}
