package pack;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.util.Iterator;
import java.util.Random;

public class Lake extends Resource{
	private int size = 10;
	private int normalSize = 10;
    private int floodedSize = size*8;
    private boolean murlocked = false;
    
    
	private Random rand = new Random();
	public Lake(int x, int y) {
		super(x, y);
		this.setName("Lake");
		this.setSize(rand.nextInt(40)+30);
		this.normalSize = size;
	}


	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}
	
	public void update() {
		if(Wysaddle.flooded == true) {
			this.size = floodedSize;
		}else {
			this.size = normalSize;
		}
	    // First, handle beings' interactions with the lake as you have already done.
	    // This part of your code can remain unchanged.

	    // Now, handle beings' interactions with other resources.
		for(int i = 0; i < Wysaddle.beings.size(); i++) {
	        Being being = Wysaddle.beings.get(i);

	        // Get being's position
	        int beingX = being.getX();
	        int beingY = being.getY();

	        // Lake boundaries
	        int lakeLeft = this.getX()+5;
	        int lakeRight = this.getX() + this.getSize()+5;
	        int lakeTop = this.getY()-5;
	        int lakeBottom = this.getY() + this.getSize()+20;

	        // Check if the being is within the lake boundaries
	        if (beingX >= lakeLeft && beingX <= lakeRight && beingY >= lakeTop && beingY <= lakeBottom) {
	            // Being is on the lake, move it away
	            // Determine the shortest direction to move the being out of the lake
	            int moveUp = Math.abs(beingY - lakeTop);
	            int moveDown = Math.abs(lakeBottom - beingY);
	            int moveLeft = Math.abs(beingX - lakeLeft);
	            int moveRight = Math.abs(lakeRight - beingX);

	            // Find the minimum distance to move out of the lake
	            int minMove = Math.min(Math.min(moveUp, moveDown), Math.min(moveLeft, moveRight));

	            // Move the being out of the lake
	            if (minMove == moveUp) {
	                being.setY(being.getY() - minMove);
	            } else if (minMove == moveDown) {
	                being.setY(being.getY() + minMove);
	            } else if (minMove == moveLeft) {
	                being.setX(being.getX() - minMove);
	            } else if (minMove == moveRight) {
	                being.setX(being.getX() + minMove);
	            }
	        }
	    }
		
	
		int beingX = getX();
	    int beingY = getY();

	    Iterator<Resource> iterator = Wysaddle.stuff.iterator();
	    while (iterator.hasNext()) {
	        Resource resource = iterator.next();
	        // Calculate the boundaries of the resource
	        int resourceLeft = resource.getX()- (this.getSize())+5;
	        int resourceRight = resource.getX() +  (this.getSize())+5; // Assuming fixed size, adjust as needed
	        int resourceTop = resource.getY()-  (this.getSize())-5;
	        int resourceBottom = resource.getY() + (this.getSize())+20; // Assuming fixed size, adjust as needed

	        // Check if the being is within the resource's boundaries
	        if (beingX >= resourceLeft && beingX <= resourceRight && beingY >= resourceTop && beingY <= resourceBottom && resource != this) {
	            iterator.remove(); // Remove the resource safely during iteration
	        }
	    }
	}

	
	public void draw(Graphics2D g2d) {
        g2d.setColor(Color.BLUE); 
        g2d.fillOval(this.getX(), this.getY(), this.getSize(), this.getSize());
	}


	public boolean isMurlocked() {
		return murlocked;
	}


	public void setMurlocked(boolean murlocked) {
		this.murlocked = murlocked;
	}
	
}
