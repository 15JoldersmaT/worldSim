package pack;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

public class Resource {
	private int x,y;
	private int energy;
	private String name;
	private String moveCode;
	Random rand = new Random();
	public Resource(int x, int y) {
		this.x = x;
		this.y = y;
		this.energy = 4;
	}
	
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}

	
	public void update() {
		if(this.energy <= 0) {
			//Ants.foods.remove(this);
		}
		

	}
	public void draw(Graphics2D g2d) {
		g2d.setColor(new Color(136, 103, 78));
		g2d.fillRect(x, y, 10, 10);
	
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	
	
}
