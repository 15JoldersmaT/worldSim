package pack;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.util.Random;

public class Tree extends Resource{
	private Random rand = new Random();
	private int g = rand.nextInt(100)+50;
	private String morph = "circle";
	public Tree(int x, int y) {
		super(x, y);
		this.setName("Tree");
		int t = rand.nextInt(2);
		if (t==1) {
			this.setMorph("circle");
		}else {
			this.setMorph("triangle");
		}
	}
	
	public void update() {
		int t = rand.nextInt(200);
		if (t == 1 && Wysaddle.stuff.size() < 3500) {
			int t2 = rand.nextInt(10);
			Tree t3 = new Tree (this.getX() - (rand.nextInt(20) -10),this.getY() - (rand.nextInt(20) -10));

			if (t2 == 1) {
			    t3 = new Tree (this.getX() - (rand.nextInt(160) -80),this.getY() - (rand.nextInt(160) -80));

			}else {
				t3 = new Tree (this.getX() - (rand.nextInt(20) -10),this.getY() - (rand.nextInt(20) -10));
			}
			if (t3.getX() < 20) {
				t3.setX(20+ rand.nextInt(30));
			}
			if (t3.getX() >1000) {
				t3.setX(1000 - rand.nextInt(30));
			}
			if (t3.getY() < 20) {
				t3.setY(20+ rand.nextInt(30));
			}
			if (t3.getY() >800 ) {
				t3.setY(800 - rand.nextInt(30));
			}
			t3.setMorph(this.morph);
			Wysaddle.stuff.add(t3);
		}
        int yy = rand.nextInt(160);
        if(yy == 1) {
		for (int i = 0;i <Wysaddle.stuff.size();i++) {
			double oX = Wysaddle.stuff.get(i).getX();
            double oY = Wysaddle.stuff.get(i).getY();

            double dX = this.getX() - oX;
            double dY = this.getY() - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
        	yy = rand.nextInt(100);
            if(dist < 25 && Wysaddle.stuff.get(i).getName() == "Tree" ) {

            if(yy == 1) {
	            	
	            		Wysaddle.stuff.remove(this);
	            }
            }
	        }
		}
	}

	public void draw(Graphics2D g2d) {
		if(this.morph == "circle") {
		
		// Ensure anti-aliasing is enabled for smoother shapes
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw the trunk of the tree
        int trunkWidth = 10 / 4;
        int trunkX = this.getX() - trunkWidth / 2;
        int trunkY = this.getY() - 10;
        g2d.setColor(new Color(139, 69, 19)); // A brown color for the trunk
        g2d.fillRect(trunkX, trunkY, trunkWidth, 10);

        // Draw the canopy of the tree
        g2d.setColor(new Color(0, g,0)); // A green color for the canopy
        Ellipse2D.Double canopy = new Ellipse2D.Double(getX() - 8 / 2, getY() - 10 - 10 / 2 * 1.5, 10, 10);
        g2d.fill(canopy);
        
		// Ensure anti-aliasing is enabled for smoother shapes
		}else {
			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	
			// Draw the trunk of the tree
			int trunkWidth = 10 / 4;
			int trunkX = this.getX() - trunkWidth / 2;
			int trunkY = this.getY() - 20;
			g2d.setColor(new Color(139, 69, 19)); // A brown color for the trunk
			g2d.fillRect(trunkX, trunkY, trunkWidth, 10);
	
			// Draw the triangle-shaped canopy of the tree
			g2d.setColor(new Color(0, g, 0)); // A green color for the canopy
			int[] xPoints = {this.getX() - 5, this.getX(), this.getX() + 5};
			int[] yPoints = {this.getY() - 20, this.getY() - 30, this.getY() - 20};
			int nPoints = 3;
			g2d.fillPolygon(xPoints, yPoints, nPoints);
		}
	}

	public String getMorph() {
		return morph;
	}

	public void setMorph(String morph) {
		this.morph = morph;
	}
}
