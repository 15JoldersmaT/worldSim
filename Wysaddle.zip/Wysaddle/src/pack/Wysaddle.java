package pack;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class Wysaddle extends JPanel implements ActionListener{
	
	private static Timer timer;
	public static List<Being> beings = new ArrayList<>();
	public static List<Resource> stuff = new ArrayList<>();
	public static List<Building> buildings = new ArrayList<>();


	private Random rand =new Random();
	public static boolean paused = false;
	public static boolean flooded = false;
	public static int maxPop =1100;
	public Wysaddle() {
		setPreferredSize(new Dimension(1005, 800));
        setBackground(new Color(100,250,100));
        initGame();
	}
	
	private void initGame() {
    	
        Color c = new Color(rand.nextInt(155),rand.nextInt(155),rand.nextInt(155));
        for (int i = 0;i<10;i++) {
        	if (i == 0) {
        	    c = new Color(190, 83, 28); // Subdued Orange
        	} else if (i == 1) {
        	    c = new Color(190, 80, 180); // Soft Blue
        	} else if (i == 2) {
        	    c = new Color(120,0,0); // Muted Lime Green
        	} else if (i == 3) {
        	    c = new Color(0, 123, 167); // Deep Sky Blue
        	} else if (i == 4) {
        	    c = new Color(25, 0, 190); // Warm Beige
        	} else if (i == 6) {
        	    c = new Color(168, 33, 147); // Soft Magenta
        	} else if (i == 9) {
        	    c = new Color(1, 1, 2); // Earthy Grey
        	} else if (i == 7) {
        	    c = new Color(104, 34, 139); // Muted Purple
        	} else if (i == 8) {
        	    c = new Color(108, 107, 75); // Olive Green
        	} else if (i == 5) {
        	    c = new Color(190, 30, 49); // Dark Coral
        	}
        	
        	for (int i2 = 0;i2<1;i2++) {
            	Human h = new Human(rand.nextInt(1000), rand.nextInt(800),c);
            	beings.add(h);
            	Tree t = new Tree(h.getX(),h.getY());
            	stuff.add(t);
            }
           // c = new Color(rand.nextInt(155),rand.nextInt(155),rand.nextInt(155));

        
        }
        for (int i2 = 0;i2<10;i2++) {
        	Lake l = new Lake(rand.nextInt(1000),rand.nextInt(800)+50);
        	stuff.add(l);
        }
        for (int i2 = 0;i2<250;i2++) {
        	Tree t = new Tree(rand.nextInt(1000),rand.nextInt(800)+50);
        	stuff.add(t);
        }
        for (int i2 = 0;i2<2;i2++) {
        	//Spider sp = new Spider(rand.nextInt(1000),rand.nextInt(800), new Color(1,1,1));
        	//beings.add(sp);
        }
        
       
        timer = new Timer(100, this);
        timer.start();
    }
	
	private void updateGame() {
    	if(paused == false) {
    		for (int i = 0;i<beings.size();i++) {
        		beings.get(i).update();
        	}
    		for (int i = 0;i<stuff.size();i++) {
        		stuff.get(i).update();
        	}
    		for (int i = 0;i<buildings.size();i++) {
    			buildings.get(i).update();
        	}
    		
    	
    	}
        repaint();
    }
	 private void initGameComponents() {
	        // Stop the existing timer and clear all action listeners.
	        if (timer != null) {
	            timer.stop();
	            for (ActionListener al : timer.getActionListeners()) {
	                timer.removeActionListener(al);
	            }
	        }
	        
	        // Reinitialize the game entities.
	        beings.clear();
	  
	        
	        // Re-setup the game environment.
	        initGame();
	        
	        // Reinitialize and start the timer.
	        timer = new Timer(1, this);
	        timer.start();
	    }
	 
	 
	  @Override
	    protected void paintComponent(Graphics g) {
	        super.paintComponent(g);
	        doDrawing(g);
	    }

	    private void doDrawing(Graphics g) {
	        Graphics2D g2d = (Graphics2D) g;
	        
	   
	        
	        
	       
	        
	        for (Resource resource : stuff) {
	            resource.draw(g2d);
	        }
	       
	        for (Building building : buildings) {
	            building.draw(g2d);
	        }
	        
	        for (Being being : beings) {
	            being.draw(g2d);
	        }
	        
	        
	        
	     // Example of adding text to the screen
	        if (paused) {
	            g2d.setColor(Color.LIGHT_GRAY); // Set the text color

	        	g2d.fillRect(850, 50, 150, 360);
	            g2d.setColor(Color.WHITE); // Set the text color
	            g2d.setFont(new Font("Arial", Font.BOLD, 16)); // Set the font
	            g2d.drawString("Game Paused", 850, 20); // Draw the string
	            g2d.setFont(new Font("Arial", Font.BOLD, 16)); // Set the font
	            g2d.drawString("Total Population " +  beings.size(), 850, 40); // Draw the string
	            
	         // Optionally, you can display other information in a similar manner
	            // For example, showing coordinates when debugging
	            g2d.setColor(Color.YELLOW);
	            g2d.setFont(new Font("Arial", Font.PLAIN, 12));
	            //g2d.drawString("Mouse X: " + mX + ", Mouse Y: " + mY, 10, 700);
	            Map<Color, Integer> colorCounts = new HashMap<>();
	            for (Being being : beings) {
	                Color color = being.getC();
	                colorCounts.put(color, colorCounts.getOrDefault(color, 0) + 1);
	            }
	            
	            int yPos = 70; // Starting Y position for color counts
	            g2d.setFont(new Font("Arial", Font.BOLD, 20)); // Set the font larger for color counts

	            for (Map.Entry<Color, Integer> entry : colorCounts.entrySet()) {
	                g2d.setColor(entry.getKey()); // Set the text color to the being's color
	                g2d.drawString(entry.getValue().toString(), 880, yPos);
	                yPos += 30; // Move to the next line for each color, with more space due to larger text
	            }
	            
	            // Reset color for any further text
	        }
	        
	        
	        
	       
	    }

	 
	    
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Tribes!");
            Wysaddle gamePanel = new Wysaddle();
            gamePanel.initGameComponents(); // Restart game
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(gamePanel);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            
            frame.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                	
	                 if(e.getKeyCode() == KeyEvent.VK_P) {
	                	 if(paused == false) {
	                		 paused = true;
	                	 }else {
	                		 paused = false;
	                	 }
	                 }
	                 if(e.getKeyCode() == KeyEvent.VK_F) {
	                	 if(flooded == false) {
	                		 flooded = true;
	                	 }else {
	                		 flooded = false;
	                	 }
	                 }
                }
            });
            frame.addMouseListener(new MouseAdapter() {
            	public void mouseClicked(MouseEvent e) {
                    // Adjust the position if necessary to align with your component's layout
                    int mX = e.getX() - 5; // Adjust these values based on your frame's layout
                    int mY = e.getY() - 35; // Subtracting to account for title bar height and any other offsets

                    // Check which mouse button was clicked
                    if (e.getButton() == MouseEvent.BUTTON1) { // Left click
                        // Create and add a Spider to the beings list
                        Spider sp = new Spider(mX, mY, Color.BLACK); // Assuming the Spider constructor takes x, y, and Color
                        beings.add(sp);
                    	
                    } else if (e.getButton() == MouseEvent.BUTTON3) { // Right click (BUTTON3 is the right mouse button)
                        // Create and add a Tiger to the beings list
                        Tiger ti = new Tiger(mX, mY, Color.ORANGE); // Assuming the Tiger constructor takes x, y, and Color
                        beings.add(ti);
                    }else if (e.getButton() == MouseEvent.BUTTON2) { 
                    	Horse h = new Horse(mX, mY, Color.ORANGE); 
                    	
                        beings.add(h);
                    	// Right click (BUTTON3 is the right mouse button)
                        // Create and add a Tiger to the beings list
                       // Horseman h = new Horseman(mX, mY, Color.ORANGE); 
                       // beings.add(h);
                    }
                }
                
            });
        });

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		updateGame();
	}

}
