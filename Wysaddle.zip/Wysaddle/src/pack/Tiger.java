package pack;



import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

public class Tiger extends Being {
	private Random rand = new Random();
    private final int baseSize = 20; // Base size of the spider's body
    private double scale = .3; // Initial scale factor
    private boolean hurt =false;
	public Tiger(int x, int y, Color c) {
		super(x, y, c);
			this.setX(x);
			this.setY(y);
			this.setC(new Color(1,1,1));
	}
	
	
	public void draw(Graphics2D g2d) {
		 // Adjust dimensions and positions based on the scale factor
	    int bodyWidth = (int) (40 * scale);
	    int bodyHeight = (int) (20 * scale);
	    int headWidth = (int) (20 * scale);
	    int headHeight = (int) (20 * scale);
	    int eyeSize = (int) (3 * scale);
	    int legOffsetX = (int) (10 * scale);
	    int legLength = (int) (10 * scale);
	    int earOffsetX = (int) (2 * scale);
	    int earOffsetY = (int) (15 * scale);
	    
	    // Basic stroke setup
	    g2d.setStroke(new BasicStroke((float) (2 * scale)));
	    g2d.setColor(Color.ORANGE);

	    

	    
	    
	    g2d.setColor(Color.BLACK);

	    // Ears
	    g2d.drawLine(getX() + bodyWidth / 1 - headWidth / 4 - earOffsetX, getY() - headHeight / 2, 
	                 getX() + bodyWidth / 1 - headWidth / 4 - earOffsetX, getY() - headHeight / 2 - earOffsetY);
	    g2d.drawLine(getX() + bodyWidth / 1 + headWidth / 4 + earOffsetX, getY() - headHeight / 2, 
	                 getX() + bodyWidth / 1 + headWidth / 4 + earOffsetX, getY() - headHeight / 2 - earOffsetY);
	    
	    // Legs
	    g2d.setStroke(new BasicStroke((float) (1 * scale)));
	    for (int i = 0; i < 4; i++) {
	        g2d.drawLine(getX() + legOffsetX * i + (legOffsetX / 5), getY() - (bodyHeight/4), 
	                     getX() + legOffsetX * i + (legOffsetX / 5), getY() - (bodyHeight/4) + legLength);
	    }
	    g2d.setColor(Color.ORANGE);

	 // Body
	    g2d.fillOval(getX(), getY() - (bodyHeight), bodyWidth, bodyHeight);
	 // Head
	    g2d.fillOval(getX() + bodyWidth / 1 - headWidth / 2, getY() - headHeight / 2, headWidth, headHeight);
	 // Eyes
	    g2d.setColor(Color.BLACK);
	    g2d.fillOval(getX() + bodyWidth / 1 - headWidth / 4 + (int) (1 * scale), getY(), eyeSize, eyeSize);
	    g2d.fillOval(getX() + bodyWidth / 1 + headWidth / 4 - (int) (4 * scale), getY(), eyeSize, eyeSize);

	}

	public void update() {
		
		//how long will the tiger be hurt for?
		int hurtChance = rand.nextInt(1000);
   	 	if (hurtChance == 1) {
   		 this.hurt = false;
   	 	}
		Random rand = new Random();
		int mC = rand.nextInt(300);
		if (mC == 0) {
			setMoveCode("Left");
		}
		else if(mC == 1) {
			setMoveCode("Right");

		}
		else if(mC == 2) {
			setMoveCode("Down");
		
		}
		else if(mC == 3) {
			setMoveCode("Up");

		}
		else if(mC == 4) {
			setMoveCode("LeftUp");

		}
		else if(mC == 5) {
			setMoveCode("LeftDown");

		}
		else if(mC == 6) {
			setMoveCode("RightUp");

		}
		else if(mC == 7) {
			setMoveCode("RightDown");

		}	
		
		if (this.getMoveCode() == "Left") {
			this.setX(this.getX()-1); 

		}else if(this.getMoveCode() == "Right") {
			this.setX(this.getX()+1); 

		}
		else if(this.getMoveCode() == "Down") {
			this.setY(this.getY()+1); 

		}
		else if(this.getMoveCode() == "Up") {
			this.setY(this.getY()-1); 

		}
		else if(this.getMoveCode() == "LeftUp") {
			this.setY(this.getY()-1); 
			this.setX(this.getX()-1); 


		}
		else if(this.getMoveCode() == "LeftDown") {
			this.setY(this.getY()+1); 
			this.setX(this.getX()-1); 

		}
		
		else if(this.getMoveCode() == "RightUp") {
			this.setY(this.getY()-1); 
			this.setX(this.getX()+1); 
		}
		else if(this.getMoveCode() == "RightDown") {
			this.setY(this.getY()+1); 
			this.setX(this.getX()+1); 
		}
		
		for (int i = 0;i<Wysaddle.beings.size();i++) {
			double oX = Wysaddle.beings.get(i).getX();
	        double oY = Wysaddle.beings.get(i).getY();
	
	        double dX = this.getX() - oX;
	        double dY = this.getY() - oY;
	
	        double dist = (dX*dX)+(dY*dY);
	        dist = Math.sqrt(dist);
       	    Color c = Wysaddle.beings.get(i).getC();
       	    if (this.scale >= .6) {
	        	 this.scale -= .5;

    		 for (int ss = 0;ss<rand.nextInt(4)+1;ss++) {
    			 Tiger sp = new Tiger(this.getX(), this.getY(), c);
    			 Wysaddle.beings.add(sp);
    		 }
    		 Wysaddle.beings.remove(this);
       	    }
	        if(dist < 35 && Wysaddle.beings.get(i)!= this && (!(c.getRed() == 1 && c.getGreen() == 1 && c.getBlue() == 1))) {
	        	if (this.hurt == false) {
		        	if (this.getX() < Wysaddle.beings.get(i).getX()) {
		        		this.setX(this.getX()+14);
		        	}
		        	
		        	if (this.getX() > Wysaddle.beings.get(i).getX()) {
		        		this.setX(this.getX()-14);
		        	}
		        	
		        	if (this.getY() < Wysaddle.beings.get(i).getY()) {
		        		this.setY(this.getY()+14);
		        	}
		        	
		        	if (this.getY() > Wysaddle.beings.get(i).getY()) {
		        		this.setY(this.getY()-14);
		        	}
	        	}else {
	        		if (this.getX() < Wysaddle.beings.get(i).getX()) {
		        		this.setX(this.getX()-12);
		        	}
		        	
		        	if (this.getX() > Wysaddle.beings.get(i).getX()) {
		        		this.setX(this.getX()+12);
		        	}
		        	
		        	if (this.getY() < Wysaddle.beings.get(i).getY()) {
		        		this.setY(this.getY()-12);
		        	}
		        	
		        	if (this.getY() > Wysaddle.beings.get(i).getY()) {
		        		this.setY(this.getY()+12);
	        	}
	        }
	        try {
	     
	        
		        if(dist <55 && Wysaddle.beings.get(i)!= this) {
		        	
		        	
		        	
		         if (((c.getRed() == 1 && c.getGreen() == 1 && c.getBlue() == 1))) {
		        	 if (this.getX() < Wysaddle.beings.get(i).getX()) {
			        		this.setX(this.getX()+12);
			        	}
			        	
			        	if (this.getX() > Wysaddle.beings.get(i).getX()) {
			        		this.setX(this.getX()-12);
			        	}
			        	
			        	if (this.getY() < Wysaddle.beings.get(i).getY()) {
			        		this.setY(this.getY()+12);
			        	}
			        	
			        	if (this.getY() > Wysaddle.beings.get(i).getY()) {
			        		this.setY(this.getY()-12);
			        	}
			     }
		         double t =rand.nextDouble(5 - (1+(this.scale*3)));
		         int t2 = rand.nextInt(50);
		         int t3 = rand.nextInt(150);
		         
		         if (t <= 1 && (!(c.getRed() == 1 && c.getGreen() == 1 && c.getBlue() == 1))) {
		        	 Wysaddle.beings.remove(i);
		        	if(this.scale <= .7) {
			        	this.scale += .01;
		        	}
		         }
		         if (t3 == 1 && (!(c.getRed() == 1 && c.getGreen() == 1 && c.getBlue() == 1))) {
		        	
		        	 int hurtChance2 = rand.nextInt(15);
		        	 if (hurtChance2 != 1) {
		        		 this.hurt = true;
		        	 }else {
			        	 Wysaddle.beings.remove(this);
			        	 
			         }
		         }
		        
		        }
	        }catch(Exception e) {
	        	
	        }
	       
	        }
		}
		
		
		
		for (int i = 0;i<Wysaddle.buildings.size();i++) {
			double oX = Wysaddle.buildings.get(i).getX();
	        double oY = Wysaddle.buildings.get(i).getY();
	
	        double dX = this.getX() - oX;
	        double dY = this.getY() - oY;
	
	        double dist = (dX*dX)+(dY*dY);
	        dist = Math.sqrt(dist);
       	    Color c = Wysaddle.buildings.get(i).getC();
       	  
	        if(dist < 55  && (!(c.getRed() == 1 && c.getGreen() == 1 && c.getBlue() == 1))) {
	        	
		        	
	        		this.hurt = true;
	        		if (dist<15 && Wysaddle.buildings.get(i).getName() == "WatchTower") {
		        		Wysaddle.beings.remove(this);
	        		}
	        		if( Wysaddle.buildings.get(i).getName() == "House") {
		        		if (this.getX() > Wysaddle.buildings.get(i).getX()) {
			        		this.setX(this.getX()+12);
			        	}
			        	
			        	if (this.getX() < Wysaddle.buildings.get(i).getX()) {
			        		this.setX(this.getX()-12);
			        	}
			        	
			        	if (this.getY() > Wysaddle.buildings.get(i).getY()) {
			        		this.setY(this.getY()+12);
			        	}
			        	
			        	if (this.getY() < Wysaddle.buildings.get(i).getY()) {
			        		this.setY(this.getY()-12);
			        	}
	        		}
	        		
	        	
	        }
	        
	        
	        
		}
		if (this.getX() < 0) {
			this.setX(0);
		}
		if (this.getX() > 1000) {
			this.setX(1000);
		}
		if (this.getY() < 30) {
			this.setY(30);
		}
		if(this.getY() > 780) {
			this.setY(780);
		}
		
		
		
	}

	public int getBaseSize() {
		return baseSize;
	}


	public boolean getHurt() {
		return hurt;
	}


	public void setHurt(boolean hurt) {
		this.hurt = hurt;
	}

}

