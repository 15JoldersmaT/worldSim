package pack;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.Random;

public class Hearth extends Building {

	public Hearth(int x, int y, Color c) {
		super(x, y, c);
		// TODO Auto-generated constructor stub
		this.setName("Hearth");
	}
	
	
	Random rand = new Random();
	public void draw(Graphics2D g2d) {
		// Ensure anti-aliasing is enabled for smoother shapes
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int t = rand.nextInt(3);
        // Adding slightly more detail to the fire
        // Draw the base of the fire
     

        
        if(t==1) {
        	g2d.setColor(new Color(255, 165, 0)); // Orange color for the base of the fire
            g2d.fillOval(getX() + 2, getY() + 4, 11, 9);
         // Add yellow part of the fire
            g2d.setColor(Color.YELLOW);
        	g2d.fillOval(getX() + 4, getY() + 6, 5, 5);
        }else {
        	g2d.setColor(new Color(255, 165, 0)); // Orange color for the base of the fire
            g2d.fillOval(getX() + 3, getY() + 5, 9, 7);
         // Add yellow part of the fire
            g2d.setColor(Color.YELLOW);
        	g2d.fillOval(getX() + 5, getY() + 7, 7, 7);

        }
        // Draw a small log
        g2d.setColor(this.getC()); // Brown color for the log
        g2d.fillRect(getX() + 4, getY() + 12, 7, 2); // Drawing the log at the base of the fire
	}
	
	

}
