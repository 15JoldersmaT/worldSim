package pack;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.util.Random;

public class Building {
	
	private int x,y;
	private Color c;
	private Random rand = new Random();
	private String name;
	
	public Building(int x, int y, Color c) {
		this.x = x;
		this.y = y;
		this.c = c;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	public void draw(Graphics2D g2d) {
		// Ensure anti-aliasing is enabled for smoother shapes
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.setColor(this.getC());
        g2d.fillRect(x, y, 20, 20);
	}

	
	public void update() {
		int uC1 = rand.nextInt(2000);
		if (uC1 == 1) {
			Wysaddle.buildings.remove(this);
		}

	}
	public Color getC() {
		return c;
	}

	public void setC(Color c) {
		this.c = c;
	}
	
	public void setName(String x) {
		this.name = x;
	}

	public String getName() {
		return this.name;
	}
}
