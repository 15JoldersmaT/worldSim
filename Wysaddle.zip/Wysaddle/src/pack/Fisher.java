package pack;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;

public class Fisher extends Being{

	public Fisher(int x, int y, Color c) {
		super(x, y, c);
		// TODO Auto-generated constructor stub
	}
	
	public void draw(Graphics2D g2d) {
		g2d.setColor(this.getC());
		// Head
	    g2d.fillOval(getX(), getY(), 5 * 2, 5 * 2);
	    // Body
	    g2d.drawLine(getX() + 5, getY() + 5 * 2, getX() + 5, getY() + 5 * 6);
	    // Arms
	    g2d.drawLine(getX(), getY() + 5 * 4, getX() + 5 * 2, getY() + 5 * 4);
	    // Legs
	    g2d.drawLine(getX() + 5, getY() + 5 * 6, getX(), getY() + 5 * 8);
	    g2d.drawLine(getX() + 5, getY() + 5 * 6, getX() + 5 * 2, getY() + 5 * 8);
	    // Fishing rod
	    g2d.draw(new Line2D.Double(getX() + 5 * 2, getY() + 5 * 4, getX() + 5 * 5, getY() + 5 * 2));
	    g2d.drawLine(getX() + 5 * 5, getY() + 5 * 2, getX() + 5 * 5, getY() + 5 * 10); // Line going into the water
	}
	

}
