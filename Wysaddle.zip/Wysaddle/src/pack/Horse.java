package pack;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Horse extends Being{

	double scale = .4;
	private String morph = "black";
	private Random rand = new Random();
	public Horse(int x, int y, Color c) {
		super(x, y, c);
		// TODO Auto-generated constructor stub
		this.setName("Horse");
		int t = rand.nextInt(3);
		if (t==1) {
			morph = "black";
		}else if (t==2) {
			morph = "white";
		}
	}

	public void update() {
		
	
		Random rand = new Random();
		int t2 = ThreadLocalRandom.current().nextInt(90000);
	    if (t2 == 1) {
	        Wysaddle.beings.remove(this);
	    }
		int mC = rand.nextInt(130);
		if (mC == 0) {
			setMoveCode("Left");
		}
		else if(mC == 1) {
			setMoveCode("Right");

		}
		else if(mC == 2) {
			setMoveCode("Down");
		
		}
		else if(mC == 3) {
			setMoveCode("Up");

		}
		else if(mC == 4) {
			setMoveCode("LeftUp");

		}
		else if(mC == 5) {
			setMoveCode("LeftDown");

		}
		else if(mC == 6) {
			setMoveCode("RightUp");

		}
		else if(mC == 7) {
			setMoveCode("RightDown");

		}
		
		if (this.getMoveCode() == "Left") {
			this.setX(this.getX()-1); 

		}else if(this.getMoveCode() == "Right") {
			this.setX(this.getX()+1); 

		}
		else if(this.getMoveCode() == "Down") {
			this.setY(this.getY()+1); 

		}
		else if(this.getMoveCode() == "Up") {
			this.setY(this.getY()-1); 

		}
		else if(this.getMoveCode() == "LeftUp") {
			this.setY(this.getY()-1); 
			this.setX(this.getX()-1); 


		}
		else if(this.getMoveCode() == "LeftDown") {
			this.setY(this.getY()+1); 
			this.setX(this.getX()-1); 

		}
		
		else if(this.getMoveCode() == "RightUp") {
			this.setY(this.getY()-1); 
			this.setX(this.getX()+1); 
		}
		else if(this.getMoveCode() == "RightDown") {
			this.setY(this.getY()+1); 
			this.setX(this.getX()+1); 
		}
		int horses = 1;
		for (int g = 0;g<Wysaddle.beings.size();g++) {
			if(Wysaddle.beings.get(g).getName() == "Horse") {
				horses+=1;
			}
		}
		for (int i = 0;i<Wysaddle.beings.size();i++) {
			double oX = Wysaddle.beings.get(i).getX();
	        double oY = Wysaddle.beings.get(i).getY();
	
	        double dX = this.getX() - oX;
	        double dY = this.getY() - oY;
	
	        double dist = (dX*dX)+(dY*dY);
	        dist = Math.sqrt(dist);
       	    Color c = Wysaddle.beings.get(i).getC();
     
	        if(dist < 155 && Wysaddle.beings.get(i)!= this && Wysaddle.beings.get(i).getC() != this.getC()) {
	        		int mCC = rand.nextInt(1*(horses*1));
	        		if(mCC == 1) {
		        		if (this.getX() < Wysaddle.beings.get(i).getX()) {
			        		this.setX(this.getX()-1);
			        	}
			        	
			        	if (this.getX() > Wysaddle.beings.get(i).getX()) {
			        		this.setX(this.getX()+1);
			        	}
			        	
			        	if (this.getY() < Wysaddle.beings.get(i).getY()) {
			        		this.setY(this.getY()-1);
			        	}
			        	
			        	if (this.getY() > Wysaddle.beings.get(i).getY()) {
			        		this.setY(this.getY()+1);
		   
			        	}
	        		}

		        if(dist <=6 && Wysaddle.beings.get(i).getName() == "Spearman" ) {
		        	try {
		        		int yy = rand.nextInt(4);
		        		if (yy <= 2) {
		        			 Horseman H = new Horseman(this.getX(), this.getY(), Wysaddle.beings.get(i).getC());
		        			 // Assuming you want the Horseman to inherit the horse's "morph" as well
		        			 H.setMorph(this.getMorph());
		        			 // No need to reset the color if it's already set correctly in the constructor
		        			 Wysaddle.beings.add(H);
		        			 int yy2 = rand.nextInt(2*(horses*2));
		        			 if (yy2 == 1) {
			        			 Horse H1 = new Horse(this.getX(), this.getY(), Color.ORANGE);
			        			 // Assuming you want the Horseman to inherit the horse's "morph" as well
			        			 H1.setMorph(this.getMorph());
			        			 // No need to reset the color if it's already set correctly in the constructor
			        			 Wysaddle.beings.add(H1);
			        		
		        			 }
		        			 Wysaddle.beings.remove(this);
		        		}else {
		        			//this.setC(Wysaddle.beings.get(i).getC());
		        		}
		        	}catch(Exception e) {
		        		
		        	}
		        
		        
		        }
	        
	       
	        }else if(dist < 85 && Wysaddle.beings.get(i)!= this && Wysaddle.beings.get(i).getName() == "Horse") {
	        	int yy =rand.nextInt(1 *(horses*4));
	        	if(yy == 1) {
	        		//count horses
	        		
	        		int birthChance = rand.nextInt(1* ((horses)+1));
	        		if (birthChance == 1 && Wysaddle.beings.size() < Wysaddle.maxPop && dist < 10) {
	        			Horse h = new Horse(this.getX(),this.getY(),this.getC());
	        			Wysaddle.beings.add(h);
	        		}
		        	if (this.getX() < Wysaddle.beings.get(i).getX()) {
		        		this.setX(this.getX()+2);
		        	}
		        	
		        	if (this.getX() > Wysaddle.beings.get(i).getX()) {
		        		this.setX(this.getX()-2);
		        	}
		        	
		        	if (this.getY() < Wysaddle.beings.get(i).getY()) {
		        		this.setY(this.getY()+2);
		        	}
		        	
		        	if (this.getY() > Wysaddle.beings.get(i).getY()) {
		        		this.setY(this.getY()-2);
		        	}
	        	}
	        }
		}
		
		
	
		 if (this.getX() < 0) {
				this.setX(0);
			}
			if (this.getX() > 1000) {
				this.setX(1000);
			}
			if (this.getY() < 30) {
				this.setY(30);
			}
			if(this.getY() > 780) {
				this.setY(780);
			}

	}
	
	
	public void draw(Graphics2D g2d) {
		if(morph == "black") {
	    	g2d.setColor(new Color(15,15,15));
	    }else if(morph == "white"){
	    	g2d.setColor(Color.WHITE);
	    }else {
	    	g2d.setColor(Color.GRAY);
	    }
		// Body
		g2d.fillOval(getX(), getY(), 20, 10); // Larger rectangle for horse body
		// Head
		g2d.fillRect(getX() + 20, getY() - 5, 5, 5); // Small rectangle for head
		// Legs - Thicker
		int legThickness = 2; // Adjust thickness as desired
		int legHeight = 5; // Adjust for height consistency
		// Front legs
		g2d.fillRect(getX() + 2, getY() + 8, legThickness, legHeight);
		// Back legs
		g2d.fillRect(getX() + 16, getY() + 8, legThickness, legHeight);
	}

	public String getMorph() {
		return morph;
	}

	public void setMorph(String morph) {
		this.morph = morph;
	}
}
