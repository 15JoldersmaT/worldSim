package pack;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Spearman extends Being {

    public Spearman(int x, int y, Color c) {
		super(x, y, c);
		this.setX(x);
		this.setY(y);
		this.setC(c);
		this.setName("Spearman");
	}

	Random rand = new Random();
	
	public void update() {
		int t2 = ThreadLocalRandom.current().nextInt(2200);
	    if (t2 == 1) {
	        Wysaddle.beings.remove(this);
	    }
	    int mC = rand.nextInt(30);
		if (mC == 0)  {
			this.setMoveCode("Left");
		}
		else if(mC == 1   ) {
			this.setMoveCode("Right");

		}
		else if(mC == 2  ) {
			this.setMoveCode("Down");
		
		}
		else if(mC == 3 ) {
			this.setMoveCode("Up");

		}
		else if(mC == 4) {
			setMoveCode("LeftUp");

		}
		else if(mC == 5) {
			setMoveCode("LeftDown");

		}
		else if(mC == 6) {
			setMoveCode("RightUp");

		}
		else if(mC == 7) {
			setMoveCode("RightDown");

		}else {
			setMoveCode("None");
		}
		
		if (this.getMoveCode() == "Left") {
			this.setX(this.getX()-2);

		}else if(this.getMoveCode() == "Right") {
			this.setX(this.getX()+2);;

		}
		else if(this.getMoveCode() == "Down") {
			this.setY(this.getY() + 2);

		}
		else if(this.getMoveCode() == "Up") {
			this.setY(this.getY() - 2);

		}
		else if(this.getMoveCode() == "LeftUp") {
			this.setY(this.getY() - 1);
			this.setX(this.getX() -1 );


		}
		else if(this.getMoveCode() == "LeftDown") {
			this.setY(this.getY() + 1);
			this.setX(this.getX() - 1);

		}
		
		else if(this.getMoveCode() == "RightUp") {
			this.setY(this.getY() - 1);
			this.setX(this.getX() + 1);
		}
		else if(this.getMoveCode() == "RightDown") {
			this.setY(this.getY() + 1);
			this.setX(this.getX() + 1);
		}
		
		
		
		if (this.getX() < 0) {
			this.setX(0);;
		}
		if (this.getX() > 1000) {
			this.setX(1000);
		}
		if (this.getY() < 30) {
			this.setY(30);
		}
		if(this.getY() > 780) {
			this.setY(780);
		}
		
		for (int i = 0;i <Wysaddle.beings.size();i++) {
			double oX = Wysaddle.beings.get(i).getX();
            double oY = Wysaddle.beings.get(i).getY();

            double dX = this.getX() - oX;
            double dY = this.getY() - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < 75  && Wysaddle.beings.get(i).getC() != this.getC() ) {
            	
		            	
		            	
		            	
		            	if (this.getY() <= Wysaddle.beings.get(i).getY()) {
		            	    this.setY(this.getY() + 2); // Should be this.setY
		            	}

		            	if (this.getY() > Wysaddle.beings.get(i).getY()) {
		            	    this.setY(this.getY() - 2); // Should be this.setY
		            	}

		            	if (this.getX() > Wysaddle.beings.get(i).getX()) {
		            	    this.setX(this.getX() - 2); // Should be this.setY
		            	}

		            	if (this.getX() <= Wysaddle.beings.get(i).getX()) {
		            	    this.setX(this.getX() + 2); // Should be this.setY
		            	}

		            
		            	if(dist <=4 && Wysaddle.beings.get(i).getName() != "Horse "&&(!(Wysaddle.beings.get(i).getC().getRed() == 1 && Wysaddle.beings.get(i).getC().getGreen() == 1 && Wysaddle.beings.get(i).getC().getBlue() == 1))) {
		            		if (Wysaddle.beings.get(i).getName() != "Horseman" && Wysaddle.beings.get(i).getName() == "Human") {
		            			int captureC = rand.nextInt(5);
			            		if(captureC==1) {
			            			Wysaddle.beings.get(i).setC(this.getC());
			            		}else {
			            				Wysaddle.beings.remove(i);
			            		}
		            		}else {
		            			int death = rand.nextInt(15);
			            		if(death==1) {
			            			if(Wysaddle.beings.get(i).getName() != "Horse") {
			            				Wysaddle.beings.remove(i);
			            			}
			            		}
		            			
		            		}
		            		
		            	}
            		
            	
            	
            }
		}
		
		for (int i = 0;i<Wysaddle.buildings.size();i++) {
			double oX = Wysaddle.buildings.get(i).getX();
	        double oY = Wysaddle.buildings.get(i).getY();
	
	        double dX = this.getX() - oX;
	        double dY = this.getY() - oY;
	
	        double dist = (dX*dX)+(dY*dY);
	        dist = Math.sqrt(dist);
       	    Color c1 = Wysaddle.buildings.get(i).getC();

	        if(dist < 55 && c1 != this.getC()) {
	       	    if (this.getX() < Wysaddle.buildings.get(i).getX()) {
	       	    	this.setX(this.getX()+1);
	       	    }
	     	
	       	    if (this.getX() > Wysaddle.buildings.get(i).getX()) {
	       	    	this.setX(this.getX()-1);
	       	    }
	     	
	       	    if (this.getY() < Wysaddle.buildings.get(i).getY()) {
	       	    	this.setY(this.getY()+1);
	       	    }
	     	
	       	    if (this.getY() > Wysaddle.buildings.get(i).getY()) {
	       	    	this.setY(this.getY()-1);
	       	    }
	       	    if(dist<= 5) {
	       	    	Wysaddle.buildings.remove(Wysaddle.buildings.get(i));
	       	    }
	        }
       	  
	        
	       
			}
	

	}
	
	public void draw(Graphics2D g2d) {
			g2d.setColor(this.getC());
	        // Adjust positions to accommodate larger size
	        drawHumanoid(g2d, this.getX(), this.getY()); // Basic figure for reference
	        drawWithSpear(g2d,this.getX(), this.getY()); // With Spear
	    
	    }

	    private void drawHumanoid(Graphics g2d, int x, int y) {
	    	 g2d.setColor(this.getC());
	    	    g2d.fillRect(x, y, 4, 4); // Head remains the same

	    	    // Set thicker stroke for the body and limbs
	    	    float thickness = 3; // Increase the thickness here
	    	    ((Graphics2D) g2d).setStroke(new BasicStroke(thickness));

	    	    // Body - make thicker
	    	    g2d.drawLine(x + 2, y + 4, x + 2, y + 12);

	    	    // Reset to default stroke for other parts if necessary
	    	    ((Graphics2D) g2d).setStroke(new BasicStroke(1));

	    	    // Arms - consider making these thicker in a similar way if desired
	    	    g2d.drawLine(x, y + 8, x + 4, y + 8); // Adjusted position for visual consistency

	    	    // Legs - consider making these thicker in a similar way if desired
	    	    g2d.drawLine(x + 2, y + 12, x, y + 16); // Left Leg
	    	    g2d.drawLine(x + 2, y + 12, x + 4, y + 16); // Right Leg
	    }

	    // With Spear
	    private void drawWithSpear(Graphics g2d, int x, int y) {
	        g2d.setColor(getC());

	        drawHumanoid(g2d, x, y);
	        g2d.drawLine(x + 4, y + 4, x + 10, y); // Spear
	    }
}
