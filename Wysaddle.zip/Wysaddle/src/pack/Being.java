package pack;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;

public class Being {

	private int x,y;
	private Color c;
	private Random rand = new Random ();
	private String moveCode ="Left";
	private int targetX, targetY;
	private String name = "none";
	private boolean hasTarget = false;
	public Being(int x, int y, Color c) {
		this.x = x;
		this.y = y;
		this.c = c;
	}
	
	public void update() {
		int mC = rand.nextInt(30);
		if (mC == 0 || mC == 15) {
			moveCode = "Left";
		}
		else if(mC == 1   ) {
			moveCode = "Right";

		}
		else if(mC == 2  ) {
			moveCode = "Down";
		
		}
		else if(mC == 3 ) {
			moveCode = "Up";

		}
		else if(mC == 4) {
			moveCode = "LeftUp";

		}
		else if(mC == 5) {
			moveCode = "LeftDown";

		}
		else if(mC == 6) {
			moveCode = "RightUp";

		}
		else if(mC == 7) {
			moveCode = "RightDown";

		}else {
			moveCode = "None";
		}
		
		if (this.moveCode == "Left") {
			this.x -= 1;

		}else if(this.moveCode == "Right") {
			this.x += 1;

		}
		else if(this.moveCode == "Down") {
			this.y += 1;

		}
		else if(this.moveCode == "Up") {
			this.y -=1;

		}
		else if(this.moveCode == "LeftUp") {
			this.y -= 1;
			this.x -= 1;


		}
		else if(this.moveCode == "LeftDown") {
			this.x -= 1;
			this.y += 1;

		}
		
		else if(this.moveCode == "RightUp") {
			this.x += 1;
			this.y -= 1;
		}
		else if(this.moveCode == "RightDown") {
			this.x += 1;
			this.y += 1;
		}
		
		if (this.x < 0) {
			this.x = 0;
		}
		if (this.x > 1000) {
			this.x = 1000;
		}
		if (this.y < 0) {
			this.y = 0;
		}
		if(this.y > 800) {
			this.y = 800;
		}
		
		for (int i = 0;i <Wysaddle.stuff.size();i++) {
			double oX = Wysaddle.stuff.get(i).getX();
            double oY = Wysaddle.stuff.get(i).getY();

            double dX = this.x - oX;
            double dY = this.y - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < 25  ) {
            	
		            	if (this.x <= Wysaddle.stuff.get(i).getX()) {
		            		this.x += 5;
		            	}
		            	
		            	if (this.x > Wysaddle.stuff.get(i).getX()) {
		            		this.x -= 5;
		            	}
		            	
		            	if (this.y <= Wysaddle.stuff.get(i).getY()) {
		            		this.y += 5;
		            	}
		            	
		            	if (this.y > Wysaddle.stuff.get(i).getY()) {
		            		this.y -= 5;
		            	}
		            
		            	if(dist <=10 && Wysaddle.stuff.get(i).getName() == "Tree") {
		            		Wysaddle.stuff.remove(i);
		            		Spearman h = new Spearman(this.getX(),this.getY(),this.getC());
		            		
		            		Wysaddle.beings.add(h);
		            		Human h1 = new Human(this.getX(),this.getY(),this.getC());
		            		
		            		Wysaddle.beings.add(h1);
		            	}
            		
            	
            	
            }
		}

	}
	
	public void draw(Graphics2D g2d) {
		g2d.setColor(this.getC());
	    g2d.fillRect(x, y, 4, 4); // Head remains the same

	    // Set thicker stroke for the body and limbs
	    float thickness = 3; // Increase the thickness here
	    ((Graphics2D) g2d).setStroke(new BasicStroke(thickness));

	    // Body - make thicker
	    g2d.drawLine(x + 2, y + 4, x + 2, y + 12);

	    // Reset to default stroke for other parts if necessary
	    ((Graphics2D) g2d).setStroke(new BasicStroke(1));

	    // Arms - consider making these thicker in a similar way if desired
	    g2d.drawLine(x, y + 8, x + 4, y + 8); // Adjusted position for visual consistency

	    // Legs - consider making these thicker in a similar way if desired
	    g2d.drawLine(x + 2, y + 12, x, y + 16); // Left Leg
	    g2d.drawLine(x + 2, y + 12, x + 4, y + 16); // Right Leg
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public Color getC() {
		return c;
	}
	
	public String getMoveCode() {
		return this.moveCode;
	}
	public void setC(Color c) {
		this.c = c;
	}
	public void setMoveCode(String move) {
		this.moveCode = move;
	}

	public int getTargetX() {
		return targetX;
	}

	public void setTargetX(int targetX) {
		this.targetX = targetX;
	}

	public int getTargetY() {
		return targetY;
	}

	public void setTargetY(int targetY) {
		this.targetY = targetY;
	}

	public boolean isHasTarget() {
		return hasTarget;
	}

	public void setHasTarget(boolean hasTarget) {
		this.hasTarget = hasTarget;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	
}
