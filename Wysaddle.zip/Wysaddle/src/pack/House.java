package pack;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.Iterator;
import java.util.Random;

public class House extends Building {

	private Random rand = new Random();
	public House(int x, int y, Color c) {
		super(x, y, c);
		this.setName("House");
		// TODO Auto-generated constructor stub
	}
	
	public void draw(Graphics2D g2d) {
		// Set the color for the hut
		g2d.setColor(new Color(this.getC().getRed()+45,this.getC().getGreen()+45,this.getC().getBlue()+45));

        // Calculate scaled dimensions
        int width = 20; // Smaller width for scaling down
        int height = 15; // Smaller height for scaling down
        int roofHeight = 10; // Height of the roof
        
        // Main body of the hut
        g2d.fillRect(getX(), getY(), width, height);

        // Roof - darker shade for contrast
        g2d.setColor(getC().darker());
        int[] xPoints = {getX() - 5, getX() + width / 2, getX() + width + 5};
        int[] yPoints = {getY(), getY() - roofHeight, getY()};
        g2d.fillPolygon(xPoints, yPoints, 3);

        // Door
        g2d.setColor(new Color(139, 69, 19)); // Darker wood color for the door
        g2d.fillRect(getX() + width / 4, getY() + height / 2, width / 4, height / 2);

        // Window
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fillRect(getX() + (3 * width / 4) - 3, getY() + height / 3, width / 6, height / 3);
        
        // Window panes
        g2d.setColor(Color.BLACK);
        g2d.drawLine(getX() + (3 * width / 4) - 3, getY() + height / 2, getX() + 5 * width / 6 - 3, getY() + height / 2);
        g2d.drawLine(getX() + width - 3 - width / 12, getY() + height / 3, getX() + width - 3 - width / 12, getY() + 2 * height / 3);
	}

	public void update() {
		if (this.getY() > 770) {
			this.setY(770);
		}
		int uC1 = rand.nextInt(5000);
		if (uC1 == 1) {
			Wysaddle.buildings.remove(this);
		}
		int beingX = getX();
	    int beingY = getY();

	    Iterator<Building> iterator = Wysaddle.buildings.iterator();
	    while (iterator.hasNext()) {
	        Building resource = iterator.next();
	        // Calculate the boundaries of the resource
	        int resourceLeft = resource.getX()-20;
	        int resourceRight = resource.getX() + 20; // Assuming fixed size, adjust as needed
	        int resourceTop = resource.getY()-20;
	        int resourceBottom = resource.getY() + 20; // Assuming fixed size, adjust as needed

	        // Check if the being is within the resource's boundaries
	        if (beingX >= resourceLeft && beingX <= resourceRight && beingY >= resourceTop && beingY <= resourceBottom && resource != this) {
	            iterator.remove(); // Remove the resource safely during iteration
	        }
	    }

	}
}
