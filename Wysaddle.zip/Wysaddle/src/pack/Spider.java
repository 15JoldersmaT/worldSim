package pack;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

public class Spider extends Being {
    private final int baseSize = 20; // Base size of the spider's body
    private double scale = .5; // Initial scale factor
    
	public Spider(int x, int y, Color c) {
		super(x, y, c);
			this.setX(x);
			this.setY(y);
			this.setC(new Color(1,1,1));
	}
	
	
	public void draw(Graphics2D g2d) {
		Random rand = new Random();
	    int bodyWidth = (int) (30 * scale);
	    int bodyHeight = (int) (20 * scale);
	    int headSize = (int) (10 * scale);

	   
	    // Legs
	    g2d.setColor(new Color(0, 100, 0));
	    int legLength = (int) (bodyWidth * 0.75);
	    int legThickness = (int) (2 * scale);
	    g2d.setStroke(new BasicStroke(legThickness));

	    // Drawing 4 legs on each side with random movement
	    for (int i = 0; i < 4; i++) {
	        int randomMovement = rand.nextInt(5) - 2; // Random movement range from -2 to 2
	        int startX = getX() - bodyWidth / 8 + (bodyWidth / 4) * i / 4;
	        int startY = getY();

	        // Upper legs (right side)
	        g2d.drawLine(startX, startY, startX + legLength / 2, startY - legLength + randomMovement);
	        g2d.drawLine(startX + legLength / 2, startY - legLength + randomMovement, startX + legLength, startY + 10 + randomMovement);

	        // Lower legs (left side)
	        g2d.drawLine(startX, startY, startX - legLength / 2, startY - legLength + randomMovement);
	        g2d.drawLine(startX - legLength / 2, startY - legLength + randomMovement, startX - legLength, startY + 10 + randomMovement);
	    }
	    
	    // Spider's body
	    g2d.setColor(new Color(0, 0, 0)); // Dark color for the spider
	    g2d.fillOval(getX() - bodyWidth / 2, getY() - bodyHeight / 2, bodyWidth, bodyHeight);
	    // Spider's head
	    g2d.fillOval(getX() - headSize / 2, getY() - bodyHeight / 2 - headSize / 2, headSize, headSize);
	    
	 // Drawing red eyes on the spider's head
	    g2d.setColor(Color.RED); // Set color for the eyes

	    // Calculate eye size and position relative to the head size and position
	    int eyeSize = (int) (headSize * 0.25); // Example size, 25% of head size
	    int eyeXOffset = (int) (headSize * 0.2); // Horizontal offset from the center of the head
	    int eyeYPosition = getY() - bodyHeight / 2 - headSize / 2 + (int) (headSize * 0.25); // Vertical position

	    // Draw left eye
	    g2d.fillOval(getX() - headSize / 2 + eyeXOffset, eyeYPosition, eyeSize, eyeSize);

	    // Draw right eye, using the same vertical position but mirrored horizontally
	    g2d.fillOval(getX() + headSize / 2 - eyeXOffset - eyeSize, eyeYPosition, eyeSize, eyeSize);

	    
	}

	public void update() {
		Random rand = new Random();
		int mC = rand.nextInt(300);
		if (mC == 0 ) {
			setMoveCode("Left");
		}
		else if(mC == 1) {
			setMoveCode("Right");

		}
		else if(mC == 2) {
			setMoveCode("Down");
		
		}
		else if(mC == 3) {
			setMoveCode("Up");

		}
		else if(mC == 4) {
			setMoveCode("LeftUp");

		}
		else if(mC == 5) {
			setMoveCode("LeftDown");

		}
		else if(mC == 6) {
			setMoveCode("RightUp");

		}
		else if(mC == 7) {
			setMoveCode("RightDown");

		}	
		
		if (this.getMoveCode() == "Left") {
			this.setX(this.getX()-1); 

		}else if(this.getMoveCode() == "Right") {
			this.setX(this.getX()+1); 

		}
		else if(this.getMoveCode() == "Down") {
			this.setY(this.getY()+1); 

		}
		else if(this.getMoveCode() == "Up") {
			this.setY(this.getY()-1); 

		}
		else if(this.getMoveCode() == "LeftUp") {
			this.setY(this.getY()-1); 
			this.setX(this.getX()-1); 


		}
		else if(this.getMoveCode() == "LeftDown") {
			this.setY(this.getY()+1); 
			this.setX(this.getX()-1); 

		}
		
		else if(this.getMoveCode() == "RightUp") {
			this.setY(this.getY()-1); 
			this.setX(this.getX()+1); 
		}
		else if(this.getMoveCode() == "RightDown") {
			this.setY(this.getY()+1); 
			this.setX(this.getX()+1); 
		}
		
		for (int i = 0;i<Wysaddle.beings.size();i++) {
			double oX = Wysaddle.beings.get(i).getX();
	        double oY = Wysaddle.beings.get(i).getY();
	
	        double dX = this.getX() - oX;
	        double dY = this.getY() - oY;
	
	        double dist = (dX*dX)+(dY*dY);
	        dist = Math.sqrt(dist);
       	    Color c = Wysaddle.beings.get(i).getC();

	        if(dist < 35 && Wysaddle.beings.get(i)!= this && (!(c.getRed() == 1 && c.getGreen() == 1 && c.getBlue() == 1))) {
	        	if (this.getX() < Wysaddle.beings.get(i).getX()) {
	        		this.setX(this.getX()+12);
	        	}
	        	
	        	if (this.getX() > Wysaddle.beings.get(i).getX()) {
	        		this.setX(this.getX()-12);
	        	}
	        	
	        	if (this.getY() < Wysaddle.beings.get(i).getY()) {
	        		this.setY(this.getY()+12);
	        	}
	        	
	        	if (this.getY() > Wysaddle.beings.get(i).getY()) {
	        		this.setY(this.getY()-12);
	        	}
	        }
	        try {
	     
	        
		        if(dist <55 && Wysaddle.beings.get(i)!= this) {
		         double t =rand.nextDouble(10 - (1+(this.scale*3)));
		         int t2 = rand.nextInt(50);
		         int t3 = rand.nextInt(205);
		         if (t <= 1 && (!(c.getRed() == 1 && c.getGreen() == 1 && c.getBlue() == 1))) {
		        	 Wysaddle.beings.remove(i);
		        	if(this.scale <= 1.7) {
			        	this.scale += .03;
		        	}
		         }
		         if (t3 == 1 && (!(c.getRed() == 1 && c.getGreen() == 1 && c.getBlue() == 1))) {
		        	
		        	 Wysaddle.beings.remove(this);
		        	 if (this.scale >= 1.7) {
		        		 for (int ss = 0;ss<2;ss++) {
		        			 Spider sp = new Spider(this.getX(), this.getY(), c);
		        			 Wysaddle.beings.add(sp);
		        		 }
		        	 }
		         }
		        	
		        }
	        }catch(Exception e) {
	        	
	        }
	        if (this.getX() < 0) {
				this.setX(0);
			}
			if (this.getX() > 1000) {
				this.setX(1000);
			}
			if (this.getY() < 30) {
				this.setY(30);
			}
			if(this.getY() > 800) {
				this.setY(800);
			}
		}
	}

	public int getBaseSize() {
		return baseSize;
	}

}
