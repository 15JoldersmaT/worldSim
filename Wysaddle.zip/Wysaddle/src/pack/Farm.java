package pack;

import java.awt.Color;
import java.awt.Graphics;

public class Farm extends Building {
	
	public Farm(int x, int y, Color c) {
		super(x, y, c);
		// TODO Auto-generated constructor stub
	}

	public void draw(Graphics g) {
		
	}

}
