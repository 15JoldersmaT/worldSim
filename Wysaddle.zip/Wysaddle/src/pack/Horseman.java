package pack;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Horseman extends Being {

	private double scale = .45;
	private String morph = "black";

	public Horseman(int x, int y, Color c) {
		super(x, y, c);
		this.setC(c);
		this.setName("Horseman");
	}
	
	
Random rand = new Random();
	
	public void update() {
		int t2 = ThreadLocalRandom.current().nextInt(3000);
	    if (t2 == 1) {
	        Wysaddle.beings.remove(this);
	    }
	    int mC = rand.nextInt(900);
		if (mC == 0)  {
			this.setMoveCode("Left");
		}
		else if(mC == 1   ) {
			this.setMoveCode("Right");

		}
		else if(mC == 2  ) {
			this.setMoveCode("Down");
		
		}
		else if(mC == 3 ) {
			this.setMoveCode("Up");

		}
		else if(mC == 4) {
			setMoveCode("LeftUp");

		}
		else if(mC == 5) {
			setMoveCode("LeftDown");

		}
		else if(mC == 6) {
			setMoveCode("RightUp");

		}
		else if(mC == 7) {
			setMoveCode("RightDown");

		}
		if (this.getMoveCode() == "Left") {
			this.setX(this.getX()-1);

		}else if(this.getMoveCode() == "Right") {
			this.setX(this.getX()+1);;

		}
		else if(this.getMoveCode() == "Down") {
			this.setY(this.getY() + 1);

		}
		else if(this.getMoveCode() == "Up") {
			this.setY(this.getY() - 1);

		}
		else if(this.getMoveCode() == "LeftUp") {
			this.setY(this.getY() - 1);
			this.setX(this.getX() -1 );


		}
		else if(this.getMoveCode() == "LeftDown") {
			this.setY(this.getY() + 1);
			this.setX(this.getX() - 1);

		}
		
		else if(this.getMoveCode() == "RightUp") {
			this.setY(this.getY() - 1);
			this.setX(this.getX() + 1);
		}
		else if(this.getMoveCode() == "RightDown") {
			this.setY(this.getY() + 1);
			this.setX(this.getX() + 1);
		}
		
		
		
		if (this.getX() < 0) {
			this.setX(0);;
		}
		if (this.getX() > 1000) {
			this.setX(1000);
		}
		if (this.getY() < 30) {
			this.setY(30);
		}
		if(this.getY() > 780) {
			this.setY(780);
		}
		
		for (int i = 0;i <Wysaddle.beings.size();i++) {
			double oX = Wysaddle.beings.get(i).getX();
            double oY = Wysaddle.beings.get(i).getY();

            double dX = this.getX() - oX;
            double dY = this.getY() - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < 75  && Wysaddle.beings.get(i).getC() != this.getC() ) {
            	
		            	
		            	
		            	if (Wysaddle.beings.get(i).getName() != "Spearman") {
			            	if (this.getY() <= Wysaddle.beings.get(i).getY()) {
			            	    this.setY(this.getY() + 1); // Should be this.setY
			            	}
	
			            	if (this.getY() > Wysaddle.beings.get(i).getY()) {
			            	    this.setY(this.getY() - 1); // Should be this.setY
			            	}
	
			            	if (this.getX() > Wysaddle.beings.get(i).getX()) {
			            	    this.setX(this.getX() - 1); // Should be this.setY
			            	}
	
			            	if (this.getX() <= Wysaddle.beings.get(i).getX()) {
			            	    this.setX(this.getX() + 1); // Should be this.setY
			            	}
		            	
		            	}else {
		            		
			            		if (this.getY() <= Wysaddle.beings.get(i).getY()) {
				            	    this.setY(this.getY() - 1); // Should be this.setY
				            	}
		
				            	if (this.getY() > Wysaddle.beings.get(i).getY()) {
				            	    this.setY(this.getY() + 1); // Should be this.setY
				            	}
		
				            	if (this.getX() > Wysaddle.beings.get(i).getX()) {
				            	    this.setX(this.getX() + 1); // Should be this.setY
				            	}
		
				            	if (this.getX() <= Wysaddle.beings.get(i).getX()) {
				            	    this.setX(this.getX() - 1); // Should be this.setY
				            	}
		            		
		            	}
		            	if(dist <=6 && (!(Wysaddle.beings.get(i).getC().getRed() == 1 && Wysaddle.beings.get(i).getC().getGreen() == 1 && Wysaddle.beings.get(i).getC().getBlue() == 1))) {
		            		int captureC = rand.nextInt(4);
		            		if(Wysaddle.beings.get(i).getName() == "Horse") {
		            			captureC = rand.nextInt(40);
		            		}
		            		if(captureC==1   && Wysaddle.beings.get(i).getName() == "Human") {
		            			Wysaddle.beings.get(i).setC(this.getC());
		            		}else {
		            			if(Wysaddle.beings.get(i).getName() != "Horse") {
		            				Wysaddle.beings.remove(i);
		            			}
		            		}
		            		
		            	}
            		
            	
            	
            }
		}
		
		for (int i = 0;i<Wysaddle.buildings.size();i++) {
			double oX = Wysaddle.buildings.get(i).getX();
	        double oY = Wysaddle.buildings.get(i).getY();
	
	        double dX = this.getX() - oX;
	        double dY = this.getY() - oY;
	
	        double dist = (dX*dX)+(dY*dY);
	        dist = Math.sqrt(dist);
       	    Color c1 = Wysaddle.buildings.get(i).getC();

	        if(dist < 55 && c1 != this.getC()) {
	       	    if (this.getX() < Wysaddle.buildings.get(i).getX()) {
	       	    	this.setX(this.getX()+1);
	       	    }
	     	
	       	    if (this.getX() > Wysaddle.buildings.get(i).getX()) {
	       	    	this.setX(this.getX()-1);
	       	    }
	     	
	       	    if (this.getY() < Wysaddle.buildings.get(i).getY()) {
	       	    	this.setY(this.getY()+1);
	       	    }
	     	
	       	    if (this.getY() > Wysaddle.buildings.get(i).getY()) {
	       	    	this.setY(this.getY()-1);
	       	    }
	       	    if(dist<= 5) {
	       	    	Wysaddle.buildings.remove(Wysaddle.buildings.get(i));
	       	    }
	        }
       	  
	        
	       
			}
	

	}
	
		public void draw(Graphics2D g2d) {
			// Apply scale to dimensions and positions
		    int bodyLength = (int) (40 * scale);
		    int bodyHeight = (int) (20 * scale);
		    int headSize = (int) (12 * scale);
		    int legWidth = (int) (6 * scale);
		    int legHeight = (int) (12 * scale);
		    int armLength = (int) (18 * scale);
		    int armHeight = (int) (4 * scale);
		    int bodyToHead = (int) (25 * scale);
		    int bodyThickness = (int) (6 * scale);
		    int legToBody = (int) (25 * scale);
		    
		    if(morph == "black") {
		    	g2d.setColor(new Color(15,15,15));
		    }else if(morph == "white"){
		    	g2d.setColor(Color.WHITE);
		    }else {
		    	g2d.setColor(Color.GRAY);
		    }
		    // Horse Body
		    g2d.fillOval(getX(), getY(), bodyLength, bodyHeight);
		    // Horse Head
		    g2d.fillRect(getX() + bodyLength, getY() - (int)(10 * scale), headSize, headSize);
		    // Horse Legs
		    g2d.fillRect(getX() + (int)(15 * scale)-5, getY() + bodyHeight-4, legWidth, legHeight);
		    g2d.fillRect(getX() + (int)(15 * scale)+10, getY() + bodyHeight-4, legWidth, legHeight);


		    g2d.setColor(getC());
		    // Rider Head
		    g2d.fillRect(getX() + (int)(20 * scale), getY() - bodyToHead, headSize, headSize);
		    // Rider Body
		    g2d.fillOval(getX() + (int)(23 * scale), getY() - bodyToHead + headSize, bodyThickness, (int)(15 * scale));
		    // Rider Arm
		    g2d.fillRect(getX() + (int)(23 * scale), getY() - bodyToHead + headSize, armLength, armHeight);
		    // Rider Leg
		    g2d.fillRect(getX() + (int)(23 * scale), getY() - bodyToHead + headSize + (int)(12 * scale), bodyThickness, legToBody);
	    }

	    private void drawHumanoid(Graphics g2d, int x, int y) {
	    	// Body
	        g2d.fillRect(x, y, 20, 10); // Larger rectangle for horse body
	        // Head
	        g2d.fillRect(x + 20, y - 5, 5, 5); // Small rectangle for head
	        // Legs
	        g2d.drawLine(x + 2, y + 10, x + 2, y + 15); // Front legs
	        g2d.drawLine(x + 18, y + 10, x + 18, y + 15); // Back legs
	    }

	    // With Spear
	    private void drawWithSpear(Graphics g2d, int x, int y) {
	        g2d.setColor(getC());

	        drawHumanoid(g2d, x, y);
	        g2d.drawLine(x + 4, y + 4, x + 10, y); // Spear
	    }

		public String getMorph() {
			return morph;
		}

		public void setMorph(String morph) {
			this.morph = morph;
		}
	

}
