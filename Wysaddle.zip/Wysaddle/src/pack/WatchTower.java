package pack;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.util.Iterator;
import java.util.Random;

public class WatchTower extends Building {

	private Random rand = new Random();
	public WatchTower(int x, int y, Color c) {
		super(x, y, c);
		// TODO Auto-generated constructor stub
		this.setName("WatchTower");
	}
	
	
	public void update() {
		if (this.getY() > 770) {
			this.setY(770);
		}
		int uC1 = rand.nextInt(5000);
		if (uC1 == 1) {
			Wysaddle.buildings.remove(this);
		}
		int beingX = getX();
	    int beingY = getY();

	    Iterator<Building> iterator = Wysaddle.buildings.iterator();
	    while (iterator.hasNext()) {
	        Building resource = iterator.next();
	        // Calculate the boundaries of the resource
	        int resourceLeft = resource.getX()-60;
	        int resourceRight = resource.getX() + 60; // Assuming fixed size, adjust as needed
	        int resourceTop = resource.getY()-60;
	        int resourceBottom = resource.getY() + 60; // Assuming fixed size, adjust as needed

	        // Check if the being is within the resource's boundaries
	        if (beingX >= resourceLeft && beingX <= resourceRight && beingY >= resourceTop && beingY <= resourceBottom && resource != this) {
	            iterator.remove(); // Remove the resource safely during iteration
	        }
	    }

	}
	public void draw(Graphics2D g2d) {
		g2d.setColor(new Color(this.getC().getRed()+45,this.getC().getGreen()+45,this.getC().getBlue()+45));
		double size = 0.6; // Scaling factor for the watchtower
        int towerWidth = (int) (30 * size);
        int towerHeight = (int) (60 * size);
        int roofHeight = (int) (15 * size);
        int baseHeight = (int) (10 * size);

        // Base of the tower
        g2d.fill(new Rectangle2D.Double(getX(), getY() + towerHeight - baseHeight, towerWidth, baseHeight));

        // Main structure of the tower
        g2d.fill(new Rectangle2D.Double(getX(), getY(), towerWidth, towerHeight));

        // Roof of the tower - triangular shape
        int[] xPoints = {getX(), getX() + towerWidth / 2, getX() + towerWidth};
        int[] yPoints = {getY(), getY() - roofHeight, getY()};
        g2d.fillPolygon(xPoints, yPoints, 3);

        // Windows of the tower
        g2d.setColor(Color.LIGHT_GRAY);
        int windowSize = (int) (5 * size);
        g2d.fillRect(getX() + towerWidth / 4, getY() + towerHeight / 3, windowSize, windowSize); // Left window
        g2d.fillRect(getX() + (3 * towerWidth / 4) - windowSize, getY() + towerHeight / 3, windowSize, windowSize); // Right window

        // Door of the tower
        int doorWidth = (int) (10 * size);
        int doorHeight = (int) (15 * size);
        g2d.fillRect(getX() + (towerWidth - doorWidth) / 2, getY() + towerHeight - baseHeight, doorWidth, doorHeight);
	}

}
