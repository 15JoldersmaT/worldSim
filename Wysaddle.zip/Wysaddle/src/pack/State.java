package pack;

public class State {
	public static int temp = 0;
	public  static boolean raining = false; 

	
}
