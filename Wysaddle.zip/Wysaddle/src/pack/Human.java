package pack;

import java.awt.Color;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Human  extends Being{
	private Random Rand = new Random();
	private boolean slowed = false;
	public Human(int x, int y, Color c) {
		super(x, y, c);
		// TODO Auto-generated constructor stub
		this.setName("Human");
	}

	public void update() {
		int t2 = ThreadLocalRandom.current().nextInt(3400);

	    if (t2 == 1) {
	        Wysaddle.beings.remove(this);
	    }
	    
	    
		t2 = ThreadLocalRandom.current().nextInt(800);
		if(t2 == 1) {
			this.slowed = false;
		}

		int mC = Rand.nextInt(30);
		if (mC == 0)  {
			this.setMoveCode("Left");
		}
		else if(mC == 1  ) {
			this.setMoveCode("Right");

		}
		else if(mC == 2  ) {
			this.setMoveCode("Down");
		
		}
		else if(mC == 3 ) {
			
			
			this.setMoveCode("Up");

		}
		else if(mC == 4) {
			setMoveCode("LeftUp");

		}
		else if(mC == 5) {
			setMoveCode("LeftDown");

		}
		else if(mC == 6) {
			setMoveCode("RightUp");

		}
		else if(mC == 7) {
			setMoveCode("RightDown");

		}else {
			setMoveCode("None");
		}
		
		if(this.slowed == false) {

			if (this.getMoveCode() == "Left") {
				this.setX(this.getX()-2);
	
			}else if(this.getMoveCode() == "Right") {
				this.setX(this.getX()+2);;
	
			}
			else if(this.getMoveCode() == "Down") {
				this.setY(this.getY() + 2);
	
			}
			else if(this.getMoveCode() == "Up") {
				this.setY(this.getY() - 2);
	
			}
		}else {
			if (this.getMoveCode() == "Left") {
				this.setX(this.getX()-1);
	
			}else if(this.getMoveCode() == "Right") {
				this.setX(this.getX()+1);;
	
			}
			else if(this.getMoveCode() == "Down") {
				this.setY(this.getY() + 1);
	
			}
			else if(this.getMoveCode() == "Up") {
				this.setY(this.getY() - 1);
	
			}
		}
		if(this.getMoveCode() == "LeftUp") {
			this.setY(this.getY() - 1);
			this.setX(this.getX() -1 );


		}
		else if(this.getMoveCode() == "LeftDown") {
			this.setY(this.getY() + 1);
			this.setX(this.getX() - 1);

		}
		
		else if(this.getMoveCode() == "RightUp") {
			this.setY(this.getY() - 1);
			this.setX(this.getX() + 1);
		}
		else if(this.getMoveCode() == "RightDown") {
			this.setY(this.getY() + 1);
			this.setX(this.getX() + 1);
		}
		
		if (this.getX() < 0) {
			this.setX(0);
		}
		if (this.getX() > 1000) {
			this.setX(1000);
		}
		if (this.getY() < 30) {
			this.setY(30);
		}
		if(this.getY() > 780) {
			this.setY(780);
		}
		
		for (int i = 0;i <Wysaddle.stuff.size();i++) {
			double oX = Wysaddle.stuff.get(i).getX();
            double oY = Wysaddle.stuff.get(i).getY();

            double dX = this.getX() - oX;
            double dY = this.getY() - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            int yy = Rand.nextInt(16);
            if(yy == 1) {
	            if(dist < 25 && Wysaddle.stuff.get(i).getName() == "Tree" ) {
	            	
			            	if (this.getX() < Wysaddle.stuff.get(i).getX()) {
			            		this.setX(this.getX()+1);
			            	}
			            	
			            	if (this.getX() > Wysaddle.stuff.get(i).getX()) {
			            		this.setX(this.getX()-1);
			            	}
			            	
			            	if (this.getY() < Wysaddle.stuff.get(i).getY()) {
			            		this.setY(this.getY()+1);
			            	}
			            	
			            	if (this.getY() > Wysaddle.stuff.get(i).getY()) {
			            		this.setY(this.getY()-1);
			            	}
			            
			            	if(dist <=10) {
			            		Random rand = new Random();
			            		int t4 = rand.nextInt(50);
			            		if (t4 == 1) {
				            		if (Wysaddle.beings.size() < 900) {
					            		Wysaddle.stuff.remove(i);
	
				            			double uC = rand.nextDouble(2 + ((Wysaddle.beings.size())+1)/85);
				            			if(uC <= 1.6) {
				            				int uC2 = rand.nextInt(2);
				            				if(uC2 == 1) {
				            					Spearman h = new Spearman(this.getX(),this.getY(),this.getC());
				            					Wysaddle.beings.add(h);
				            					System.out.println(Wysaddle.beings.size());
				            				}else if (uC2 == 0){
				            					Human h1 = new Human(this.getX(),this.getY(),this.getC());
				            					Wysaddle.beings.add(h1);
				            					System.out.println(Wysaddle.beings.size());
				            				}
				            			}
				            			
				            			int uC1 = rand.nextInt(10);
				            			if (uC1 == 1 && Wysaddle.buildings.size()< 200) {
					            			int uC2 = rand.nextInt(10);
					            			if (uC2 == 1) {
					            				WatchTower hh = new WatchTower (this.getX(),this.getY(),this.getC());
				            					Wysaddle.buildings.add(hh);
					            			}else {
					            				Hearth hh = new Hearth(this.getX(),this.getY(),this.getC());
				            					Wysaddle.buildings.add(hh);
					            			}
				            			}
	
				            			
				            		}
			            		}
			            	}
	            	
	            }
            }
		}
		
		for (int i = 0;i <Wysaddle.beings.size();i++) {
			double oX = Wysaddle.beings.get(i).getX();
            double oY = Wysaddle.beings.get(i).getY();

            double dX = this.getX() - oX;
            double dY = this.getY() - oY;

            double dist = (dX*dX)+(dY*dY);
            dist = Math.sqrt(dist);
            
            if(dist < 55  && Wysaddle.beings.get(i).getC() != this.getC() ) {

		            	
		            	if (this.getY() <= Wysaddle.beings.get(i).getY()) {
		            	    this.setY(this.getY() - 1); // Should be this.setY
		            	}

		            	if (this.getY() > Wysaddle.beings.get(i).getY()) {
		            	    this.setY(this.getY() + 2); // Should be this.setY
		            	}

		            	if (this.getX() >= Wysaddle.beings.get(i).getX()) {
		            	    this.setX(this.getX() + 1); // Should be this.setY
		            	}

		            	if (this.getX() < Wysaddle.beings.get(i).getX()) {
		            	    this.setX(this.getX() - 1); // Should be this.setY
		            	}

            }
		}
		
		for (int i = 0;i<Wysaddle.buildings.size();i++) {
			double oX = Wysaddle.buildings.get(i).getX();
	        double oY = Wysaddle.buildings.get(i).getY();
	
	        double dX = this.getX() - oX;
	        double dY = this.getY() - oY;
	
	        double dist = (dX*dX)+(dY*dY);
	        dist = Math.sqrt(dist);
       	    Color c1 = Wysaddle.buildings.get(i).getC();

	        if(dist < 55 && c1 != this.getC() && Wysaddle.buildings.get(i).getName() == "WatchTower") {
	       	    if (this.getX() < Wysaddle.buildings.get(i).getX()) {
	       	    	this.setX(this.getX()-1);
	       	    }
	     	
	       	    if (this.getX() > Wysaddle.buildings.get(i).getX()) {
	       	    	this.setX(this.getX()+1);
	       	    }
	     	
	       	    if (this.getY() < Wysaddle.buildings.get(i).getY()) {
	       	    	this.setY(this.getY()-1);
	       	    }
	     	
	       	    if (this.getY() > Wysaddle.buildings.get(i).getY()) {
	       	    	this.setY(this.getY()+1);
	       	    }
	        }
       	  
	        if(dist < 15) {
	        	
		        if(Wysaddle.buildings.get(i).getName() == "Hearth") {
		        	int r = Rand.nextInt(5000);
		        	if (r==1) {
		        		if (Wysaddle.buildings.size() < 200) {
			        		House h = new House(this.getX() + (Rand.nextInt(10)-5),this.getY() + (Rand.nextInt(10)-5),this.getC());

		        			Wysaddle.buildings.add(h);
		        			
		        		}
		        	}
		        }
	        	this.slowed=true;

	        
	        }
	       
			}
		 
		

	}
}
