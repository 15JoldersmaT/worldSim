/**
 * 
 */
/**
 * 
 */
module Wysaddle {
	requires java.desktop;
}